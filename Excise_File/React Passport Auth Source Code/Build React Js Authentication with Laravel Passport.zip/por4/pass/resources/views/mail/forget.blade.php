<!DOCTYPE html>
<html>
<head>
	<title>Forget Password </title>
</head>
<body>
HI <br>

 Change Your Password <a href="http://localhost:3000/reset/{{ $data }}">Click Here</a>
 <br>
 Pincode : {{ $data }}


</body>
</html>