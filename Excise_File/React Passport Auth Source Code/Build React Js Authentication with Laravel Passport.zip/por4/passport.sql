-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 01, 2021 at 03:34 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `passport`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_08_19_000000_create_failed_jobs_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('07c3c67d21ab625162d97ccb0783e8cc7c213559b9d684698797b9c87f3912a0c645286d4e2bc2d8', 1, 1, 'app', '[]', 0, '2021-05-02 13:42:50', '2021-05-02 13:42:50', '2022-05-02 19:42:50'),
('29bfb5671b1795a73a2a598596a8418d72ae4aaabfe1336d098a94896486eaca7e07559ce9ee986e', 3, 1, 'app', '[]', 0, '2021-05-03 17:44:44', '2021-05-03 17:44:44', '2022-05-03 23:44:44'),
('371f3816086aa44c27d0138fc9c3860ef69404d1e203d4f2f97ad4f43ef4af4e87db293115760998', 2, 1, 'app', '[]', 0, '2021-05-03 14:51:01', '2021-05-03 14:51:01', '2022-05-03 20:51:01'),
('5f50d954ca4a6d0974c82289d1289eef15015e2251184938145f316e10dc7e89a1632458f8e1c973', 2, 1, 'app', '[]', 0, '2021-05-03 17:35:27', '2021-05-03 17:35:27', '2022-05-03 23:35:27'),
('649e69e1cfa1bfb8b79a9f1734eb433a3ce40023a90d78891637f3a8851551776dc058c8b8c56978', 1, 1, 'app', '[]', 0, '2021-04-30 14:50:15', '2021-04-30 14:50:15', '2022-04-30 20:50:15'),
('6ccfce5690ddf2562e8b50dc24f9aba864d5057fcedb34f87e3531dd8e34e786e5c5446eac7d2430', 3, 1, 'app', '[]', 0, '2021-05-03 17:43:35', '2021-05-03 17:43:35', '2022-05-03 23:43:35'),
('80a6f44b710f76069e73cc4c1de889312e32f4be9715db103c8a366a6dbada0c1554fb5a40ce180f', 2, 1, 'app', '[]', 0, '2021-05-03 17:27:05', '2021-05-03 17:27:05', '2022-05-03 23:27:05'),
('a712dd8ee875db1d9135e9f523eacfaa1d05b65b100c84b4779d88688ae63a89b3265661cf6a14dd', 3, 1, 'app', '[]', 0, '2021-05-03 17:47:15', '2021-05-03 17:47:15', '2022-05-03 23:47:15'),
('c48f6ff1d011671918da1ff972b4e70264b912c00201a531130d6ef7f51b94dec2a34656c0959c98', 1, 1, 'app', '[]', 0, '2021-04-30 14:47:08', '2021-04-30 14:47:08', '2022-04-30 20:47:08'),
('c70c9b7f6ddec60cbaf365c8975c608af438829c34f7a23ceddd6c695ef16700dc05115b45673908', 1, 1, 'app', '[]', 0, '2021-05-02 14:41:38', '2021-05-02 14:41:38', '2022-05-02 20:41:38'),
('d14298f799785b5c3fa2d721f239790b37dcd28edd98f37aaccb084c24c40129422129fa8d02d94b', 1, 1, 'app', '[]', 0, '2021-05-01 13:43:11', '2021-05-01 13:43:11', '2022-05-01 19:43:11'),
('d7dabaf08ef3525eccacb90d73f0c808982b92f4d081247f89b9279fb4fe35bfeb4fb7ab4ceaf005', 1, 1, 'app', '[]', 0, '2021-05-02 14:24:04', '2021-05-02 14:24:04', '2022-05-02 20:24:04'),
('f885092d2447ff6ce78eec01c1997fc77284031a841c3c0e0ffffe79f662785325b6d28bdaeeee41', 2, 1, 'app', '[]', 0, '2021-05-03 14:29:08', '2021-05-03 14:29:08', '2022-05-03 20:29:08');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_auth_codes_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `provider`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'r1jpEgMpm13LtLLMuwgryNLRDCy98jyqtijCCpMF', NULL, 'http://localhost', 1, 0, 0, '2021-04-30 13:27:49', '2021-04-30 13:27:49'),
(2, NULL, 'Laravel Password Grant Client', 'p6K38YKdlJ2irx2Pww7ap8ELtvu73l8NlUW8pfum', 'users', 'http://localhost', 0, 1, 0, '2021-04-30 13:27:49', '2021-04-30 13:27:49');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2021-04-30 13:27:49', '2021-04-30 13:27:49');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE IF NOT EXISTS `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Kazi Ariyan', 'kazi@gmail.com', NULL, '$2y$10$mSUr8eMIGQn4RDvG0F2ANuU6rIZO4mkhaxJ/yamp6KeNide3Fd4Be', NULL, '2021-04-30 14:47:08', '2021-04-30 14:47:08'),
(2, 'Udemy', 'udemy@gmail.com', NULL, '$2y$10$Zkg2l6AmdGSpO8LN34YUZuHx1LWjsvs.rV8pTV5xwvviq9QpmXsTa', NULL, '2021-05-03 14:29:04', '2021-05-03 14:29:04'),
(3, 'Test', 'test@gmail.com', NULL, '$2y$10$dkpBY7aMUpan3oxnO6/9ZuomiLu6tMTXH7Yyd/p/f5ttf3J9lQx1e', NULL, '2021-05-03 17:43:35', '2021-05-03 17:43:35');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
